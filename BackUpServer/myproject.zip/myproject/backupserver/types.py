

class CreateFolderRequestTypeClass(object):
    
    def __init__(self, folder_name='Untitled Folder', parent_id=1):
        
        self.folder_name = folder_name
        self.parent_id = parent_id