from django.contrib import admin
# from mainserver.models import Document
# admin.site.register(Document)

from common.models import FileSystem
admin.site.register(FileSystem)
# # Register your models here.
